(function(){
  // // const mymap = L.map('mapid').setView([51.505, -0.09], 13);
  // document.getElementById('forsmalldvc').onclick = function(ev) {
  //     console.log('david est le meilleur de tout les temps');
  // }
})();
